<div class="titulo">$_GET</div>

<?php
echo $_GET;
echo '<br>';
print_r($_GET);
echo "<br>{$_GET['nome']}";